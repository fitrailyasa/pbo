# 120140048 Fitra Ilyasa

from PIL import ImageTk
from PIL import Image as PilImage
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox, filedialog

# kelas kompres gambar
class Kompres_gambar(Tk):
    
    #konstruktor
    def __init__(self, judul, ukuran_x, ukuran_y, *args):
        super(Kompres_gambar, self).__init__()

        # konfigurasi tampilan
        self.geometry(f'{ukuran_x}x{ukuran_y}')
        self.title(judul)
        self.config(bg="crimson")
        self.author = Label(self, text=" by : 120140048_Fitra ", bg="white")
        self.author.place(x=0, y=0)

        # tombol-tombol
        self.tombol_pilih_gambar = Button(text="Pilih gambar", bg="white", command = self.gambar, bd=5).place(x=50, y=50)
        self.tombol_pilih_folder = Button(text="Pilih folder untuk menyimpan", bg="white", command = self.simpan, bd=5).place(x=50, y=300)
        self.tombol_kompres_gambar = Button(text="Kompres gambar", bg="white", command = self.kompres, bd=5).place(x=300, y=300)

        # skala dan kualitas gambar
        self.pilih_kualitas = Label(self, text="Pilih kualitas gambar", bg="white")
        self.pilih_kualitas.place(x=50, y=100)
        self.nilai_skala = Scale(self, from_=100, to=0)
        self.nilai_skala.place(x=50, y=120)

        # nama baru file
        self.nama_baru = Label(text="Masukkan nama baru file", bg="white",)
        self.nama_baru.place(x=50, y=250)
        self.input_nama = Entry(self)
        self.input_nama.place(x=50, y=270)
        
        self.mainloop()

    # method pilih gambar
    def gambar(self):
        self.lokasi = filedialog.askopenfilename()

        # kondisi ketika memilih lokasi gambar
        if self.lokasi:
            messagebox.showinfo("File", self.lokasi)
        else:
            messagebox.showwarning("Error", "Tidak ada gambar yg dipilih")

    # method simpan gambar
    def simpan(self):

        # kondisi ketika memilih lokasi penyimpanan gambar
        self.pilih_folder = filedialog.askdirectory()
        if self.pilih_folder:
            messagebox.showinfo("Simpan ke:", self.pilih_folder)
        else:
            messagebox.showwarning("Error", "Tidak ada folder yg dipilih")

    # method pilih gambar
    def kompres(self):

        # kondisi ketika kompres gambar
        self.skala_angka = self.nilai_skala.get()
        try:
            self.pilih_gambar = PilImage.open(self.lokasi)
            self.get_ekstensi_gambar = self.lokasi.rsplit(".", 1)
            self.ekstensi_gambar = self.get_ekstensi_gambar[1]
            self.nama_gambar = self.input_nama.get()
            self.pilih_gambar.save(f"{self.pilih_folder}/{self.nama_gambar}.{self.ekstensi_gambar}", quality = self.skala_angka)
            messagebox.showinfo("Berhasil", f"Hasil disimpan ke {self.pilih_folder}")
        except:
            messagebox.showwarning("Error", "Terjadi kesalahan")
            
# instansiasi objek
coba = Kompres_gambar("Kompres Gambar", 600, 400)
